from . import res_company
from . import hr_payroll_ci
from . import hr_holidays
from . import hr_employee
from . import hr_payroll_structure_type
