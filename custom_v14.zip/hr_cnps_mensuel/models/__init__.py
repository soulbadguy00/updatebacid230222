from . import hr_cnps_settings
from . import hr_cnps_monthly
from . import hrPayslip
