from . import res_config_settings
from . import hr_payroll_analyse
from . import HrSalaryRule
from . import hr_payslip
from . import Hr_dasc